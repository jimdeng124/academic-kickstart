import multiprocessing
import numpy as np

from os import cpu_count


def worker():
    # TODO 1: Add all necessary arguments to the function signature.
    # TODO 2: Complete the code below so that it computes A_{I, :} x
    #         for a submatrix A_{I,:} of A.
    pass


def parallel_matvec(A: np.ndarray, x: np.ndarray, nproc: int):
    """Compute the matrix-vector product A * x in parallel.

    Arguments
    ---------
    A : numpy.ndarray
        The input matrix.
    x : numpy.ndarray
        The input vector.
    nproc : int
        The number of parallel processes to use.

    Returns
    -------
    numpy.ndarray
        A vector holding the result of the operation `A * x`.

    Raises
    ------
    ValueError
        If the number of processes is not strictly positive.
    """
    processes = []
    # TODO:
    # 1. Determine the number of rows of A to give per process.
    # 2. Initialize a shared array to write results to in subprocesses.
    for i in range(nproc):
        # TODO: Your code here.
        # Remove the `pass` statement when you are done.
        pass

    for proc in processes:
        proc.join()

    # TODO: Return the expected output


if __name__ == "__main__":
    A = np.random.randn(100, 50)
    x = np.random.rand(50)
    y_numpy = A @ x
    nproc = cpu_count()
    if nproc:
        y_nonnumpy = parallel_matvec(A, x, 2 * nproc)
    else:
        y_nonnumpy = parallel_matvec(A, x, 1)
    print(np.linalg.norm(y_nonnumpy - y_numpy))
